SwingStates, Version 0.2

Copyright (c) Université Paris-Sud XI, 2007.

SwingStates.jar (in directory lib) contains all binary and source files to write a Java program using SwingStates. To write a SwingStates program, add SwingStates.jar it to your Java classpath.

SwingStates tutorial (http://swingstates.sourceforge.net/tutorial/index.html) contains a set of applet examples to help you start with SwingStates. The source code for these applets is located in package fr.lri.swingstates.applets.